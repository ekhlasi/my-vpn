# 🚀 BNDMAX VPN

<p align="center">
  <img src="https://img.shields.io/badge/version-1.2.0-blue.svg" alt="Version">
  <img src="https://img.shields.io/badge/platform-Cloudflare%20Workers-orange.svg" alt="Platform">
  <img src="https://img.shields.io/badge/license-MIT-green.svg" alt="License">
  <img src="https://img.shields.io/badge/language-TypeScript-blueviolet.svg" alt="Language">
</p>

<p align="center">
  <strong>پروکسی پرسرعت و امن بر بستر Cloudflare Workers</strong>
</p>

<p align="center">
  <a href="#-نکته-مهم">نکته مهم</a> •
  <a href="#-درباره-پروژه">درباره پروژه</a> •
  <a href="#-ویژگی‌ها">ویژگی‌ها</a> •
  <a href="#-پیش‌نیازها">پیش‌نیازها</a> •
  <a href="#-نصب-و-راه‌اندازی">نصب و راه‌اندازی</a> •
  <a href="#-تنظیمات-محیطی">تنظیمات محیطی</a> •
  <a href="#-صفحات-پروژه">صفحات پروژه</a> •
  <a href="#-پشتیبانی">پشتیبانی</a>
</p>

---

## ⚠️ نکته مهم

> این پروژه به‌صورت **متن‌باز (Open Source)** توسعه یافته و کاملاً منطبق با **قوانین جمهوری اسلامی ایران** طراحی و پیاده‌سازی شده است.
>
> استفاده از این سرویس صرفاً بر عهده‌ی **شخص کاربر** بوده و تیم توسعه‌دهنده هیچ‌گونه مسئولیتی در قبال استفاده‌های نادرست، مغایر با قوانین، یا هرگونه سوءاستفاده از این ابزار نخواهد داشت.
>
> لطفاً پیش از استفاده، از رعایت کامل قوانین و مقررات کشور خود اطمینان حاصل فرمایید.

---

## 📖 درباره پروژه

**BNDMAX VPN** یک سرویس پروکسی مدرن است که بر روی **Cloudflare Workers** اجرا می‌شود. این پروژه با بهره‌گیری از شبکه جهانی Cloudflare، تجربه‌ای سریع، امن و پایدار را برای کاربران فراهم می‌کند.

---

## ✨ ویژگی‌ها

- ⚡ **سرعت برق‌آسا** – استفاده از زیرساخت‌های پیشرفته برای کمترین تأخیر
- 🔒 **امنیت پیشرفته** – رمزنگاری و پروتکل‌های امنیتی در سطح سازمانی
- 🌐 **شبکه جهانی** – دسترسی از هر نقطه با سرورهای متعدد در سراسر جهان
- 🎨 **رابط کاربری زیبا** – طراحی مدرن با پشتیبانی از تم روشن/تاریک
- 📱 **واکنش‌گرا** – سازگار با تمام دستگاه‌ها (موبایل، تبلت، دسکتاپ)
- 🔄 **اشتراک‌گذاری آسان** – تولید لینک اشتراک VLESS با یک کلیک
- 📋 **کپی سریع** – کپی پیکربندی VLESS در کلیپ‌بورد
- 🌐 **Private DNS عمومی** – لیست عمومی دامنه/آی‌پی/رنج که سرور DoT مستقل
  ([`dot-server/`](./dot-server)) طبق آن بعضی مقصدها را از پروکسی کلادفلر و
  بقیه را مستقیم resolve می‌کند؛ جزئیات و محدودیت‌ها:
  [`docs/private-dns-fa.md`](./docs/private-dns-fa.md)

---

## 📋 پیش‌نیازها

- یک حساب [Cloudflare](https://dash.cloudflare.com/)
- آشنایی پایه با [Cloudflare Workers](https://developers.cloudflare.com/workers/)
- Node.js و npm (برای توسعه)

---

## 🛠 نصب و راه‌اندازی

### ۱. کلون کردن مخزن

```bash
git clone https://github.com/yourusername/bndmax-vpn.git
cd bndmax-vpn